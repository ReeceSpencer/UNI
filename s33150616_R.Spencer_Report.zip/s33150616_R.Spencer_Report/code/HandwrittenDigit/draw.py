from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, Dropout, Flatten, MaxPooling2D
from tensorflow.keras.utils import to_categorical
import tensorflow as tf
import tkinter as tk
import os
import PIL
from cv2 import cv2
import glob
import numpy as np
from PIL import Image, ImageDraw, ImageGrab
from time import process_time

(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()

x_train.shape

x_train = x_train.reshape(x_train.shape[0], 28, 28, 1).astype('float32')
x_test = x_test.reshape(x_test.shape[0], 28, 28, 1).astype('float32')
input_shape = (28, 28, 1)
x_train /= 255
x_test /= 255

y_train = to_categorical(y_train)
y_test = to_categorical(y_test)

print('x_train shape:', x_train.shape)
print('Number of images in x_train', x_train.shape[0])
print('Number of images in x_test', x_test.shape[0])

start = process_time()

def create_model():
    model = Sequential()
    model.add(Conv2D(16, kernel_size=(3,3), activation='relu', input_shape=input_shape))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Conv2D(32, kernel_size=(3,3), activation='relu', input_shape=input_shape))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    #model.add(Conv2D(64, (3,3), activation='relu'))
    #model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.25))
    model.add(Flatten())
    model.add(Dense(256, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(10,activation='softmax'))
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

model = create_model()

model.fit(x_train, y_train, validation_data=(x_test, y_test), epochs=10, batch_size=200, verbose=2)
print('The model has successfully trained')

scores = model.evaluate(x_test, y_test)
end = process_time()
print('Neural network error: %.2f%%' % (100-scores[1]*100))
print("time taken (seconds): ", end - start)

root = tk.Tk()
root.resizable(0,0)
root.title('Digit Recognition')

lastx, lasty = None, None
image_number = 0

def Clear_Widget():
    global canvas
    canvas.delete('all')

def Activate_Event(event):
    global lastx, lasty
    canvas.bind('<B1-Motion>', Draw_Lines)
    lastx, lasty = event.x, event.y

def Draw_Lines(event):
    global lastx, lasty
    x, y = event.x, event.y
    canvas.create_line((lastx, lasty, x, y), width=8, fill='black', capstyle=tk.ROUND, smooth=tk.TRUE, splinesteps=12)
    lastx, lasty = x, y

def Recognise_Digit():
    global image_number
    filename = f'image_{image_number}.png'
    widget = canvas

    x=root.winfo_rootx()+widget.winfo_x()
    y=root.winfo_rooty()+widget.winfo_y()
    xl=x+widget.winfo_width()
    yl=y+widget.winfo_height()

    ImageGrab.grab().crop((x, y, xl, yl)).save(filename)
    image = cv2.imread(filename, cv2.IMREAD_COLOR)
    grey = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    ret,th = cv2.threshold(grey, 0, 255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
    contours = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]

    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        cv2.rectangle(image, (x, y), (x+w, y+h), (255,0,0), 1)
        top = int(0.05 * th.shape[0])
        bottom = top
        left = int(0.05 * th.shape[1])
        right = left
        th_up = cv2.copyMakeBorder(th, top, bottom, left, right, cv2.BORDER_REPLICATE)
        roi = th[y-top:y+h+bottom, x-left:x+w+right]
        img = cv2.resize(roi, (28,28), interpolation = cv2.INTER_AREA)
        img = img.reshape(1,28,28,1)
        img = img/255
        pred = model.predict([img])[0]
        final_pred = np.argmax(pred)
        data = str(final_pred) + ' ' + str(int(max(pred)*100))+'%'
        font = cv2.FONT_HERSHEY_SIMPLEX
        colour = (255, 0, 0)
        cv2.putText(image, data, (x, y-5), font, 0.5, colour, 1)
    cv2.imshow('image', image)
    cv2.waitKey(0)

canvas = tk.Canvas(root, width=500, height=500, bg='white')
canvas.grid(row=0, column=0, pady=2, sticky=tk.W, columnspan=2)
canvas.bind('<Button-1>', Activate_Event)

btn_save = tk.Button(root, text='Recognise Digit', command=Recognise_Digit)
btn_save.grid(row=2, column=0, pady=1, padx=1)

btn_clear = tk.Button(root, text='Clear Widget', command=Clear_Widget)
btn_clear.grid(row=2, column=1, pady=1, padx=1)

root.mainloop()